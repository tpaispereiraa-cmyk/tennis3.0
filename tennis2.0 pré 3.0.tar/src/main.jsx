import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './ui/App.jsx';
import './styles/appTheme.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
